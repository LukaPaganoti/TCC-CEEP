-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/08/2023 às 00:38
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `studiosbentcc`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_categorias`
--

CREATE TABLE `tb_categorias` (
  `codcategoria` int(11) NOT NULL,
  `descricaocat` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_cidades`
--

CREATE TABLE `tb_cidades` (
  `codcidade` int(11) NOT NULL,
  `nomecid` varchar(50) DEFAULT NULL,
  `estadocid` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_clientes`
--

CREATE TABLE `tb_clientes` (
  `codcliente` int(11) NOT NULL,
  `nomecli` varchar(50) DEFAULT NULL,
  `telefonecli` bigint(11) DEFAULT NULL,
  `cpfcli` bigint(12) DEFAULT NULL,
  `senhacli` varchar(32) DEFAULT NULL,
  `usuariocli` varchar(50) DEFAULT NULL,
  `emailcli` varchar(150) DEFAULT NULL,
  `tipocadastro` varchar(1) DEFAULT NULL,
  `ativo` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_clientes`
--

INSERT INTO `tb_clientes` (`codcliente`, `nomecli`, `telefonecli`, `cpfcli`, `senhacli`, `usuariocli`, `emailcli`, `tipocadastro`, `ativo`) VALUES
(1, 'Luiza Maria Paganoti Farias', 45998073523, 12759755932, 'cheshaneko', 'Luiza Maria', 'bendrownedstudios@gmail.com', 'C', 'S');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_enderecos`
--

CREATE TABLE `tb_enderecos` (
  `codendereco` int(11) NOT NULL,
  `cepend` int(11) DEFAULT NULL,
  `numeroend` int(11) DEFAULT NULL,
  `bairroend` varchar(100) DEFAULT NULL,
  `ruaend` varchar(100) DEFAULT NULL,
  `complementoend` varchar(255) NOT NULL,
  `fk_codcliente` int(11) NOT NULL,
  `fk_codcidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_imagens_prod`
--

CREATE TABLE `tb_imagens_prod` (
  `codimagem_prod` int(11) NOT NULL,
  `produtoimg` varchar(255) DEFAULT NULL,
  `fk_codproduto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_pedidos`
--

CREATE TABLE `tb_pedidos` (
  `codpedido` int(11) NOT NULL,
  `codtransporte` varchar(50) NOT NULL,
  `tipoped` varchar(2) DEFAULT NULL,
  `pagamento` varchar(1) DEFAULT NULL,
  `valor_entrega` float(5,2) DEFAULT NULL,
  `fk_codcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_pedidos_prod`
--

CREATE TABLE `tb_pedidos_prod` (
  `codpedido_prod` int(11) NOT NULL,
  `precoped` float(5,2) DEFAULT NULL,
  `quantidadeped` float(3,3) NOT NULL,
  `fk_codpedido` int(11) NOT NULL,
  `fk_codproduto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `codproduto` int(11) NOT NULL,
  `nomeprod` varchar(60) DEFAULT NULL,
  `precoprod` float(5,2) DEFAULT NULL,
  `tamanhoprod` float(4,2) DEFAULT NULL,
  `pesoprod` tinyint(1) DEFAULT NULL,
  `descricaoprod` varchar(255) DEFAULT NULL,
  `ativo` varchar(1) DEFAULT NULL,
  `fk_codcategoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_categorias`
--
ALTER TABLE `tb_categorias`
  ADD PRIMARY KEY (`codcategoria`);

--
-- Índices de tabela `tb_cidades`
--
ALTER TABLE `tb_cidades`
  ADD PRIMARY KEY (`codcidade`);

--
-- Índices de tabela `tb_clientes`
--
ALTER TABLE `tb_clientes`
  ADD PRIMARY KEY (`codcliente`);

--
-- Índices de tabela `tb_enderecos`
--
ALTER TABLE `tb_enderecos`
  ADD PRIMARY KEY (`codendereco`);

--
-- Índices de tabela `tb_imagens_prod`
--
ALTER TABLE `tb_imagens_prod`
  ADD PRIMARY KEY (`codimagem_prod`);

--
-- Índices de tabela `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  ADD PRIMARY KEY (`codpedido`);

--
-- Índices de tabela `tb_pedidos_prod`
--
ALTER TABLE `tb_pedidos_prod`
  ADD PRIMARY KEY (`codpedido_prod`);

--
-- Índices de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`codproduto`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_categorias`
--
ALTER TABLE `tb_categorias`
  MODIFY `codcategoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_cidades`
--
ALTER TABLE `tb_cidades`
  MODIFY `codcidade` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_clientes`
--
ALTER TABLE `tb_clientes`
  MODIFY `codcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_enderecos`
--
ALTER TABLE `tb_enderecos`
  MODIFY `codendereco` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_imagens_prod`
--
ALTER TABLE `tb_imagens_prod`
  MODIFY `codimagem_prod` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_pedidos`
--
ALTER TABLE `tb_pedidos`
  MODIFY `codpedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_pedidos_prod`
--
ALTER TABLE `tb_pedidos_prod`
  MODIFY `codpedido_prod` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `codproduto` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
